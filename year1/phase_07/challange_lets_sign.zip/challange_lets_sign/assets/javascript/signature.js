/* == == == Main == == == */
// Tabs
const tabs = document.querySelectorAll('.tab_btn');

tabs.forEach(tab => tab.addEventListener('click', () => tabClicked(tab)));

const tabClicked = (tab) => {
    tabs.forEach(tab => tab.classList.remove('active'));
    tab.classList.add('active');

    const contents = document.querySelectorAll('.content');
    contents.forEach(content => content.classList.remove('show'));

    const contentId = tab.getAttribute('content-id');
    const content = document.getElementById(contentId);

    content.classList.add('show');
}

const currentActiveTab = document.querySelector('.tab_btn.active');
tabClicked(currentActiveTab);

// Signature style switcher
const styleButtons = document.querySelectorAll('.style_btn');
const input = document.getElementById('signature_input');

styleButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove all "active" classes
        styleButtons.forEach(btn => btn.classList.remove('active'));

        // Activates the clicked button
        button.classList.add('active');

        // Change the input source
        const font = button.getAttribute('data-font');
        input.style.fontFamily = font;
    });
});

// Signature draw field
const canvas = document.getElementById("signature_canvas");
const ctx = canvas.getContext("2d");

let drawing = false;
let isInitialized = false;

function initCanvas() {
    if (isInitialized) return; // Avoids multiple boots
    isInitialized = true;

    // Only now the canvas is visible and has real size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    canvas.addEventListener("mousedown", () => {
        drawing = true;
        ctx.beginPath();
    });

    canvas.addEventListener("mouseup", () => {
        drawing = false;
    });

    canvas.addEventListener("mousemove", (e) => {
        if (!drawing) return;

        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        ctx.lineWidth = 2;
        ctx.lineCap = "round";
        ctx.strokeStyle = "#000";

        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
    });
}

document.querySelectorAll(".tab_btn").forEach((btn) => {
    btn.addEventListener("click", () => {
        const contentId = btn.getAttribute("content-id");

        document.querySelectorAll(".tab_btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        document.querySelectorAll(".content").forEach(c => c.classList.remove("show"));
        document.getElementById(contentId).classList.add("show");

        if (contentId === "draw") {
            initCanvas(); // Initialize the canvas only when visible
        }
    });
});
