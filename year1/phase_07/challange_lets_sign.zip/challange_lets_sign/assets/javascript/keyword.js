const fields = Array.from({ length: 12 }, (_, i) =>
    document.getElementById(`field-${i + 1}`)
);

let selection = [];

document.querySelectorAll(".word").forEach((button) => {
    button.addEventListener("click", () => {
        const text = button.textContent;

        // Check if it is already selected
        const indexInSelection = selection.findIndex(entry => entry.word === text);

        if (indexInSelection !== -1) {
        // Remove from selection
        selection.splice(indexInSelection, 1);
        updateFields();
        button.classList.remove("selected");

        } else if (selection.length < 12) {
        // Add to next position
        selection.push({ word: text, button });
        button.classList.add("selected");
        updateFields();
        }
    });
});

function updateFields() {
    // Clear all fields
    fields.forEach(field => field.textContent = "");

    // Fill in the fields in the order of selection
    selection.forEach((entry, index) => {
        fields[index].textContent = entry.word;
    });

    // Update button states
    document.querySelectorAll(".word").forEach(button => {
        const isSelected = selection.some(entry => entry.word === button.textContent);
        button.disabled = false;
        button.classList.toggle("selected", isSelected);
    });
}
