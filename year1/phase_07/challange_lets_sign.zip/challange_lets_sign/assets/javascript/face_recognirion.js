document.getElementById("next").addEventListener("click", function (e) {
  e.preventDefault();

  const modal = document.getElementById("cameraModal");
  modal.classList.remove("hidden");

  // Acessar a câmera
  navigator.mediaDevices
    .getUserMedia({ video: true })
    .then(function (stream) {
      const video = document.getElementById("video");
      video.srcObject = stream;
    })
    .catch(function (err) {
      alert("Erro ao acessar a câmera: " + err.message);
    });
});

// (Opcional) Fechar com ESC
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeModal();
  }
});

function closeModal() {
  const modal = document.getElementById("cameraModal");
  modal.classList.add("hidden");

  const video = document.getElementById("video");
  const stream = video.srcObject;

  if (stream) {
    const tracks = stream.getTracks();
    tracks.forEach((track) => track.stop());
  }

  video.srcObject = null;
}

document.getElementById("closeModal").addEventListener("click", closeModal);
document.getElementById("sendButton").addEventListener("click", function () {
  // Aqui você pode colocar lógica de envio (ex: capturar frame)
  console.log("Foto enviada!"); // Simulação
  closeModal();
});
